// <reference path="" /> 구문을 사용해
// events, manipulation, selector, styles 파일을 임포트 합니다.

namespace Dom {
  export let version: string = "0.0.2";
}
