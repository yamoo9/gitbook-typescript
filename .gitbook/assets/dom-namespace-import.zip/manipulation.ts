namespace Dom {
  
  export function prepend(parent:Element, child:Element):void {
    parent.insertAdjacentElement('beforeend', child);
  }

  export function append(parent:Element, child:Element):void {
    parent.insertAdjacentElement('afterbegin', child);
  }

}