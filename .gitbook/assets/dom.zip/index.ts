namespace Dom {
  export let version: string = "0.0.2";
}
