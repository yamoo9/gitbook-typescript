namespace Dom {
  function getStyle(el: HTMLElement, prop: string): any {
    return window.getComputedStyle(el, "")[prop as any];
  }

  function setStyle(el: HTMLElement, prop: string, value: any): void {
    el.style[prop as any] = value;
  }

  export function css(
    el: HTMLElement,
    prop: string,
    value: number | string
  ): any {
    return !value ? getStyle(el, prop) : setStyle(el, prop, value);
  }
}
