type array_like_obj = {
  length: number;
  [prop:string]: any;
};

export function $(s:string):NodeList {
  return document.querySelectorAll(s);
};

export function each(
  o:array_like_obj, 
  cb:(item:any, index:number)=>void
):void {
  Array.prototype.forEach.call(o, cb);
}