/** Dom/version -------------------------------------------- */
namespace Dom {

  export let version: string = '0.0.2';

}


/** Dom/events --------------------------------------------- */
namespace Dom {

  export function on(
    el: Element | Document, 
    type: string, 
    handler: (e: Event) => void, 
    is_capture: boolean = false
  ): void { 
    el.addEventListener(type, handler, is_capture); 
  }

  export function off(
    el: Element | Document, 
    type: string, 
    handler: (e: Event) => void, 
    is_capture: boolean = false
  ): void { 
    el.removeEventListener(type, handler, is_capture);
  }

}


/** Dom/manipulation ---------------------------------------- */
namespace Dom {
  
  export function prepend(parent:Element, child:Element):void {
    parent.insertAdjacentElement('beforeend', child);
  }

  export function append(parent:Element, child:Element):void {
    parent.insertAdjacentElement('afterbegin', child);
  }

}


/** Dom/selector -------------------------------------------- */
namespace Dom {

  const document = window.document;

  export function el(
    selector: string, 
    context: Element | Document = document
  ): Element { 
    return context.querySelector(selector); 
  }

  export function els(
    selector: string, 
    context: Element | Document = document
  ): NodeList { 
    return context.querySelectorAll(selector); 
  }

}


/** Dom/selector -------------------------------------------- */
namespace Dom {

  function getStyle(el: HTMLElement, prop: string): any {
    return window.getComputedStyle(el, null)[prop];
  }

  function setStyle(el: HTMLElement, prop: string, value: number | string): void {
    el.style[prop] = value;
  }

  export function css(el: HTMLElement, prop: string, value: number | string): any {
    return !value ? getStyle(el, prop) : setStyle(el, prop, value);
  }

}

export default Dom;