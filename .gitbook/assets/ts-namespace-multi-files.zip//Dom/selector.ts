namespace Dom {

  const document = window.document;

  export function el(
    selector: string, 
    context: Element | Document = document
  ): Element { 
    return context.querySelector(selector); 
  }

  export function els(
    selector: string, 
    context: Element | Document = document
  ): NodeList { 
    return context.querySelectorAll(selector); 
  }

}