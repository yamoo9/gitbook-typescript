namespace Dom {

  function getStyle(el: HTMLElement, prop: string): any {
    return window.getComputedStyle(el, null)[prop];
  }

  function setStyle(el: HTMLElement, prop: string, value: number | string): void {
    el.style[prop] = value;
  }

  export function css(el: HTMLElement, prop: string, value: number | string): any {
    return !value ? getStyle(el, prop) : setStyle(el, prop, value);
  }

}