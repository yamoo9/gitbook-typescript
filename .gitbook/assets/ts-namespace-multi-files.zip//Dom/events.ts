namespace Dom {

  export function on(
    el: Element | Document, 
    type: string, 
    handler: (e: Event) => void, 
    is_capture: boolean = false
  ): void { 
    el.addEventListener(type, handler, is_capture); 
  }

  export function off(
    el: Element | Document, 
    type: string, 
    handler: (e: Event) => void, 
    is_capture: boolean = false
  ): void { 
    el.removeEventListener(type, handler, is_capture);
  }

}