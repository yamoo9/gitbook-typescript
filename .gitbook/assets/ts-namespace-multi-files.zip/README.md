# [ts-namespace-multi-files](https://stackblitz.com/edit/ts-namespace-multi-files)
